package com.vzw.vxp.bpm.accountbalance.util;

public class BPMConstants {
    public static final String REST_URL_KEY = "rest.url";
    public static final String AUTH_TYPE_KEY = "auth.type";
    public static final String CONTENT_TYPE_KEY = "content.type";
    public static final String METHOD_KEY = "http.method";
	/*
	 * public static final String USERNAME_KEY = "auth.username"; public static
	 * final String PASSWORD_KEY = "auth.password";
	 */
}
