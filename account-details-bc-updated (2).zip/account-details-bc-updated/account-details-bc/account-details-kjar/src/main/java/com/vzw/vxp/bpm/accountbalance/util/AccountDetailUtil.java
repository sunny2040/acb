package com.vzw.vxp.bpm.accountbalance.util;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.kie.api.runtime.process.ProcessContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.Serializable;

public class AccountDetailUtil implements Serializable {
    private static final long serialVersionUID = 1L;
    private static final Logger LOGGER = LoggerFactory.getLogger(AccountDetailUtil.class);

	/*
	 * before initiating request to rest call
	 */
    public void initiateRequest(ProcessContext kcontext, String failureValue, String successValue) {
        LOGGER.info("Preparing REST call details...");

        try {
            String url = PropertyFile.get(BPMConstants.REST_URL_KEY);
            String method = PropertyFile.get(BPMConstants.METHOD_KEY);
            String contentType = PropertyFile.get(BPMConstants.CONTENT_TYPE_KEY);
            String authType = PropertyFile.get(BPMConstants.AUTH_TYPE_KEY);

            LOGGER.info("REST URL: {}", url);
            LOGGER.info("HTTP Method: {}", method);
            LOGGER.info("Content-Type: {}", contentType);
            LOGGER.info("Auth Type: {}", authType);

            kcontext.setVariable(BPMConstants.REST_URL_KEY, url);
            kcontext.setVariable(BPMConstants.METHOD_KEY, method);
            kcontext.setVariable(BPMConstants.CONTENT_TYPE_KEY, contentType);
            kcontext.setVariable(BPMConstants.AUTH_TYPE_KEY, authType);
        } catch (Exception e) {
            LOGGER.error("Error preparing REST call details", e);
            throw new RuntimeException("Failed to prepare REST call", e);
        }
    }

	/*
	 * validating response after rest call
	 */
    public void validateAccountResponse(ProcessContext kcontext) {
        LOGGER.info("Validating account response...");

        try {
            String responseJson = (String) kcontext.getVariable("result");
            ObjectMapper mapper = new ObjectMapper();
            JsonNode rootNode = mapper.readTree(responseJson);
            double amount = rootNode.path("data").path("amount").asDouble();

            boolean acExist = amount == 0.0;
            kcontext.setVariable("acExist", acExist);

            LOGGER.info("Amount: {}", amount);
            LOGGER.info("Setting acExist: {}", acExist);
        } catch (Exception e) {
            LOGGER.error("Failed to validate account response", e);
            throw new RuntimeException("Response validation failed", e);
        }
    }
}
