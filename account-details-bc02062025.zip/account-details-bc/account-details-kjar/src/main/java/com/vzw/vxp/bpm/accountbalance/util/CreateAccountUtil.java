package com.vzw.vxp.bpm.accountbalance.util;

import org.kie.api.runtime.process.ProcessContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.Serializable;

public class CreateAccountUtil implements Serializable {
    private static final long serialVersionUID = 1L;
    private static final Logger LOGGER = LoggerFactory.getLogger(CreateAccountUtil.class);

    /**
     * Create Account
     *
     * onEntry: Sets up REST call config and payload
     */
    
    public void initiateCreateAccountRequest(ProcessContext kcontext) {
        LOGGER.info("Preparing Create Account REST call.");

        try {
            String createAccounturl = PropertyFile.get(BPMConstants.CREATE_ACCOUNT_URL);
            String createAccountmethod = PropertyFile.get(BPMConstants.CREATE_AC_METHOD_KEY);
            String contentType = PropertyFile.get(BPMConstants.CONTENT_TYPE_KEY);
            String authType = PropertyFile.get(BPMConstants.AUTH_TYPE_KEY);

            String aacSource = (String) kcontext.getVariable(BPMConstants.AAC_SOURCE_KEY);
            String amount = PropertyFile.get(BPMConstants.CREATE_AC_AMOUNT);
            if (aacSource == null || aacSource.trim().isEmpty()) {
                throw new IllegalArgumentException("aac_source is missing in process context");
            }
            
            if (amount == null || amount.trim().isEmpty()) {
                throw new IllegalArgumentException("amount is missing in process context");
            }

            String requestPayload = String.format("{\"aac_source\": \"%s\"}", aacSource);
            
            createAccounturl = createAccounturl + "?amount=" + amount;

            kcontext.setVariable(BPMConstants.CREATE_ACCOUNT_URL, createAccounturl);
            kcontext.setVariable(BPMConstants.CREATE_AC_METHOD_KEY, createAccountmethod);
            kcontext.setVariable(BPMConstants.CONTENT_TYPE_KEY, contentType);
            kcontext.setVariable(BPMConstants.AUTH_TYPE_KEY, authType);
            kcontext.setVariable(BPMConstants.REQUEST_PAYLOAD, requestPayload);

            LOGGER.info("REST URL: {}", createAccounturl);
            LOGGER.info("Method: {}", createAccountmethod);
            LOGGER.info("Content-Type: {}", contentType);
            LOGGER.info("Auth Type: {}", authType);
            LOGGER.info("Request Payload: {}", requestPayload);

        } catch (Exception e) {
            LOGGER.error("Error preparing Create Account REST call", e);
            throw new RuntimeException("Failed to prepare Create Account REST call", e);
        }
    }
    
    /**
     * onExit: Validates the response for Create Account
     */
    
    public void validateCreateAccountResponse(ProcessContext kcontext) {
        LOGGER.info("Validating Create Account response...");

        try {
            String response = (String) kcontext.getVariable(BPMConstants.RESULT_VARIABLE);

            if (response == null || !response.trim().equalsIgnoreCase("Amount updated successfully.")) {
                throw new RuntimeException("Unexpected response: " + response);
            }

            LOGGER.info("Create Account response validated successfully.");

        } catch (Exception e) {
            LOGGER.error("Failed to validate Create Account response", e);
            throw new RuntimeException("Create Account validation failed", e);
        }
	}

}
