package com.vzw.vxp.bpm.accountbalance.util;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.kie.api.runtime.process.ProcessContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.Serializable;

public class AccountDetailUtil implements Serializable {
    private static final long serialVersionUID = 1L;
    private static final Logger LOGGER = LoggerFactory.getLogger(AccountDetailUtil.class);

    /**
     * onEntry: Sets up REST call config and payload
     */
    public void initiateGetAccountDetailsRequest(ProcessContext kcontext) {
        LOGGER.info("Preparing Get Account Details REST call.");

        try {
            String url = PropertyFile.get(BPMConstants.GET_ACCOUNT_URL);
            String method = PropertyFile.get(BPMConstants.METHOD_KEY);
            String contentType = PropertyFile.get(BPMConstants.CONTENT_TYPE_KEY);
            String authType = PropertyFile.get(BPMConstants.AUTH_TYPE_KEY);

            String aacSource = (String) kcontext.getVariable(BPMConstants.AAC_SOURCE_KEY);
            if (aacSource == null || aacSource.trim().isEmpty()) {
                throw new IllegalArgumentException("aac_source is missing in process context");
            }

            String payload = String.format("{\"aac_source\": \"%s\"}", aacSource);
            
			/*
			 * Setting the rest config
			 */
            kcontext.setVariable(BPMConstants.GET_ACCOUNT_URL, url);
            kcontext.setVariable(BPMConstants.METHOD_KEY, method);
            kcontext.setVariable(BPMConstants.CONTENT_TYPE_KEY, contentType);
            kcontext.setVariable(BPMConstants.AUTH_TYPE_KEY, authType);
            kcontext.setVariable(BPMConstants.REQUEST_PAYLOAD, payload);

            LOGGER.info("REST URL: {}", url);
            LOGGER.info("Method: {}", method);
            LOGGER.info("Content-Type: {}", contentType);
            LOGGER.info("Auth Type: {}", authType);
            LOGGER.info("Request Payload: {}", payload);

        } catch (Exception e) {
            LOGGER.error("Error preparing REST call details", e);
            throw new RuntimeException("Failed to prepare REST call", e);
        }
    }

    /**
     * onExit: Validates the response
     */
    
    public void validateGetAccountDetailsResponse(ProcessContext kcontext) {
        LOGGER.info("Validating Get Account Details response.");

        boolean acExist = true;
        boolean isError = false;

        try {
            String responseJson = (String) kcontext.getVariable(BPMConstants.RESULT_VARIABLE);

            ObjectMapper mapper = new ObjectMapper();
            JsonNode rootNode = mapper.readTree(responseJson);

            double amount = rootNode.path("data").path("amount").asDouble();

            acExist = amount == 0.0;

            LOGGER.info("Amount from response: {}", amount);

        } catch (Exception e) {
            LOGGER.error("Failed to validate account response", e);
            isError = true;
        } finally {
            kcontext.setVariable(BPMConstants.AC_EXIST_KEY, acExist);
            kcontext.setVariable(BPMConstants.IS_ERROR_KEY, isError);
            LOGGER.info("Setting acExist: {}", acExist);
            LOGGER.info("Setting isError: {}", isError);
        }
    }
    
}
