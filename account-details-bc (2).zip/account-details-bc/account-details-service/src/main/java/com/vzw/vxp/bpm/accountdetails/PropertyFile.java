//package com.vzw.vxp.bpm.accountdetails;
//
//import org.springframework.beans.factory.annotation.Value;
//import org.springframework.stereotype.Component;
//
//@Component
//public class PropertyFile {
//
//    @Value("${jbpm.url}")
//    private String jbpmUrl;
//
//    @Value("${jbpm.containerId}")
//    private String containerId;
//
//    @Value("${jbpm.username}")
//    private String username;
//
//    @Value("${jbpm.password}")
//    private String password;
//
//    @Value("${GET_ACCOUNT_URL}")
//    private String getAccountUrl;
//
//    @Value("${GET_ACCOUNT_METHOD}")
//    private String getAccountMethod;
//
//    @Value("${CREATE_ACCOUNT_URL}")
//    private String createAccountUrl;
//
//    @Value("${CREATE_ACCOUNT_METHOD}")
//    private String createAccountMethod;
//
//    @Value("${CREATE_ACCOUNT_AMOUNT}")
//    private String createAccountAmount;
//
//    @Value("${authType}")
//    private String authType;
//
//    @Value("${contentType}")
//    private String contentType;
//
//    // getters here
//
//    public String getJbpmUrl() { return jbpmUrl; }
//    public String getContainerId() { return containerId; }
//    public String getUsername() { return username; }
//    public String getPassword() { return password; }
//    public String getGetAccountUrl() { return getAccountUrl; }
//    public String getGetAccountMethod() { return getAccountMethod; }
//    public String getCreateAccountUrl() { return createAccountUrl; }
//    public String getCreateAccountMethod() { return createAccountMethod; }
//    public String getCreateAccountAmount() { return createAccountAmount; }
//    public String getAuthType() { return authType; }
//    public String getContentType() { return contentType; }
//}