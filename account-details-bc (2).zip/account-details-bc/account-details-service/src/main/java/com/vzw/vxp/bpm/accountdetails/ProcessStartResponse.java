//package com.vzw.vxp.bpm.accountdetails;
//
//import java.util.Map;
//
//public class ProcessStartResponse {
//	private String type;
//	private Long id;
//	private String processId;
//	private String processName;
//	private String processVersion;
//	private Integer state;
//	private Map<String, Object> variables;
//	private String errorMessage;
//	private String exception;
//
//	public String getType() {
//		return type;
//	}
//
//	public void setType(String type) {
//		this.type = type;
//	}
//
//	public Long getId() {
//		return id;
//	}
//
//	public void setId(Long id) {
//		this.id = id;
//	}
//
//	public String getProcessId() {
//		return processId;
//	}
//
//	public void setProcessId(String processId) {
//		this.processId = processId;
//	}
//
//	public String getProcessName() {
//		return processName;
//	}
//
//	public void setProcessName(String processName) {
//		this.processName = processName;
//	}
//
//	public String getProcessVersion() {
//		return processVersion;
//	}
//
//	public void setProcessVersion(String processVersion) {
//		this.processVersion = processVersion;
//	}
//
//	public Integer getState() {
//		return state;
//	}
//
//	public void setState(Integer state) {
//		this.state = state;
//	}
//
//	public Map<String, Object> getVariables() {
//		return variables;
//	}
//
//	public void setVariables(Map<String, Object> variables) {
//		this.variables = variables;
//	}
//
//	public String getErrorMessage() {
//		return errorMessage;
//	}
//
//	public void setErrorMessage(String errorMessage) {
//		this.errorMessage = errorMessage;
//	}
//
//	public String getException() {
//		return exception;
//	}
//
//	public void setException(String exception) {
//		this.exception = exception;
//	}
//
//}
