//package com.vzw.vxp.bpm.accountdetails;
//
//import org.springframework.boot.context.properties.ConfigurationProperties;
//import org.springframework.stereotype.Component;
//
//@Component
//@ConfigurationProperties(prefix = "jbpm")
//public class JbpmProperties {
//
//	private String url;
//	private String username;
//	private String password;
//	private String containerId;
//
//	private String getAccountUrl;
//	private String getAccountMethod;
//	private String createAccountUrl;
//	private String createAccountMethod;
//	private String createAcAmount;
//	private String contentType;
//	private String authType;
//
//	// getters and setters for all above
//
//	public String getUrl() {
//		return url;
//	}
//
//	public void setUrl(String url) {
//		this.url = url;
//	}
//
//	public String getUsername() {
//		return username;
//	}
//
//	public void setUsername(String username) {
//		this.username = username;
//	}
//
//	public String getPassword() {
//		return password;
//	}
//
//	public void setPassword(String password) {
//		this.password = password;
//	}
//
//	public String getContainerId() {
//		return containerId;
//	}
//
//	public void setContainerId(String containerId) {
//		this.containerId = containerId;
//	}
//
//	public String getGetAccountUrl() {
//		return getAccountUrl;
//	}
//
//	public void setGetAccountUrl(String getAccountUrl) {
//		this.getAccountUrl = getAccountUrl;
//	}
//
//	public String getGetAccountMethod() {
//		return getAccountMethod;
//	}
//
//	public void setGetAccountMethod(String getAccountMethod) {
//		this.getAccountMethod = getAccountMethod;
//	}
//
//	public String getCreateAccountUrl() {
//		return createAccountUrl;
//	}
//
//	public void setCreateAccountUrl(String createAccountUrl) {
//		this.createAccountUrl = createAccountUrl;
//	}
//
//	public String getCreateAccountMethod() {
//		return createAccountMethod;
//	}
//
//	public void setCreateAccountMethod(String createAccountMethod) {
//		this.createAccountMethod = createAccountMethod;
//	}
//
//	public String getCreateAcAmount() {
//		return createAcAmount;
//	}
//
//	public void setCreateAcAmount(String createAcAmount) {
//		this.createAcAmount = createAcAmount;
//	}
//
//	public String getContentType() {
//		return contentType;
//	}
//
//	public void setContentType(String contentType) {
//		this.contentType = contentType;
//	}
//
//	public String getAuthType() {
//		return authType;
//	}
//
//	public void setAuthType(String authType) {
//		this.authType = authType;
//	}
//}