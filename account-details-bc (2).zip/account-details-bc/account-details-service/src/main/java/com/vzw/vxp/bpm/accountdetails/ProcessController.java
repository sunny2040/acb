package com.vzw.vxp.bpm.accountdetails;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.RestTemplate;

import com.vzw.vxp.bpm.accountdetails.service.ProcessStarterService;

@RestController
@RequestMapping("/process")
public class ProcessController {

    @Autowired
    private ProcessStarterService processStarterService;

    @PostMapping("/start")
    public ResponseEntity<String> start(@RequestBody Map<String, String> request) {
        String aacSource = request.get("aac_source");
        processStarterService.startGetAccountDetailsProcess(aacSource);
        return ResponseEntity.ok("Process started");
    }
}
