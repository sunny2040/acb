package com.vzw.vxp.bpm.accountdetails.service;
import org.kie.api.runtime.KieContainer;
import org.kie.api.runtime.KieSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Map;

@Service
public class ProcessStarterService {

    @Autowired
    private Environment env;

    @Autowired
    private KieContainer kieContainer;

    public void startGetAccountDetailsProcess(String aacSource) {
        // 1. Create KieSession
        KieSession kieSession = kieContainer.newKieSession();

        // 2. Set Process Variables
        Map<String, Object> vars = new HashMap<>();
        vars.put("aac_source", aacSource);
        vars.put("GET_ACCOUNT_URL", env.getProperty("GET_ACCOUNT_URL"));
        vars.put("GET_ACCOUNT_METHOD", env.getProperty("GET_ACCOUNT_METHOD"));
        vars.put("CREATE_ACCOUNT_URL", env.getProperty("CREATE_ACCOUNT_URL"));
        vars.put("CREATE_ACCOUNT_METHOD", env.getProperty("CREATE_ACCOUNT_METHOD"));
        vars.put("CREATE_ACCOUNT_AMOUNT", env.getProperty("CREATE_ACCOUNT_AMOUNT"));
        vars.put("contentType", env.getProperty("contentType"));
        vars.put("authType", env.getProperty("authType"));

        // 3. Start the process
        kieSession.startProcess("vxp.GetAccountDetails", vars);

        kieSession.dispose(); // Don't forget to clean up
    }
}
