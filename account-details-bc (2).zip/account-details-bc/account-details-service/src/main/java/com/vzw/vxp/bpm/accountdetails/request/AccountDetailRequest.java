//package com.vzw.vxp.bpm.accountdetails.request;
//
//public class AccountDetailRequest {
//    private String aac_source;
//
//    public String getAac_source() {
//        return aac_source;
//    }
//
//    public void setAac_source(String aac_source) {
//        this.aac_source = aac_source;
//    }
//}