//package com.vzw.vxp.bpm.accountbalance.util;
//
//import com.fasterxml.jackson.databind.JsonNode;
//import com.fasterxml.jackson.databind.ObjectMapper;
//import org.kie.api.runtime.process.ProcessContext;
//import org.slf4j.Logger;
//import org.slf4j.LoggerFactory;
//
//import java.io.Serializable;
//
//public class AccountDetailUtil implements Serializable {
//	private static final long serialVersionUID = 1L;
//	private static final Logger LOGGER = LoggerFactory.getLogger(AccountDetailUtil.class);
//
//	/**
//	 * 
//	 */
//	public void initiateGetAccountProcessVariables(ProcessContext kcontext) {
//		
//		kcontext.setVariable(BPMConstants.CALL_COMPENSATION, null != kcontext.getVariable(BPMConstants.CALL_COMPENSATION) ? (boolean) kcontext.getVariable(BPMConstants.CALL_COMPENSATION) : false);
//	}
//
//	
//	/**
//	 * onEntry: Sets up REST call config and payload
//	 */
//	public void initiateGetAccountDetailsRequest(ProcessContext kcontext) {
//		LOGGER.info("Entering into : initiateGetAccountDetailsRequest() method");
//
//		try {
////			String prefix = "getAccount";
////			String url = PropertyFile.get(prefix, BPMConstants.GET_ACCOUNT_URL);
////			String method = PropertyFile.get(prefix, BPMConstants.METHOD_KEY);
////			String contentType = PropertyFile.get(BPMConstants.CONTENT_TYPE_KEY);
////			String authType = PropertyFile.get(BPMConstants.AUTH_TYPE_KEY);
//			
//			String url = (String) kcontext.getVariable(BPMConstants.GET_ACCOUNT_URL);
//			String method = (String) kcontext.getVariable(BPMConstants.GET_ACCOUNT_METHOD);
//			String contentType = (String) kcontext.getVariable(BPMConstants.CONTENT_TYPE_KEY);
//			String authType = (String) kcontext.getVariable(BPMConstants.AUTH_TYPE_KEY);
//
//			String aacSource = (String) kcontext.getVariable(BPMConstants.AAC_SOURCE_KEY);
//			if (aacSource == null || aacSource.trim().isEmpty()) {
//				throw new IllegalArgumentException("aac_source is missing in process context");
//			}
//
//			String payload = String.format("{\"aac_source\": \"%s\"}", aacSource);
//
//			kcontext.setVariable(BPMConstants.GET_ACCOUNT_URL, url);
//			kcontext.setVariable(BPMConstants.GET_ACCOUNT_METHOD, method);
//			kcontext.setVariable(BPMConstants.CONTENT_TYPE_KEY, contentType);
//			kcontext.setVariable(BPMConstants.AUTH_TYPE_KEY, authType);
//			kcontext.setVariable(BPMConstants.REQUEST_PAYLOAD, payload);
//
//			LOGGER.info("REST URL for Get Account Details: {}", url);
//			LOGGER.info("Method : {}", method);
//			LOGGER.info("Content-Type: {}", contentType);
//			LOGGER.info("Auth Type: {}", authType);
//			LOGGER.info("Request Payload: {}", payload);
//
//		} catch (Exception e) {
//			LOGGER.error("Error initiateGetAccountDetailsRequest() method", e);
//			throw new RuntimeException("Failed to prepare initiateGetAccountDetailsRequest REST call", e);
//		}
//	}
//
//	/**
//	 * onExit: Validates the response
//	 */
//
//	public void validateGetAccountDetailsResponse(ProcessContext kcontext) {
//		LOGGER.info("Entering into : validateGetAccountDetailsResponse() method");
//
//		boolean isSuccess = true;
//		boolean acExist = false;
//
//		try {
//			String responseJson = (String) kcontext.getVariable(BPMConstants.RESULT_VARIABLE);
//			ObjectMapper mapper = new ObjectMapper();
//			JsonNode rootNode = mapper.readTree(responseJson);
//
//			double amount = rootNode.path("data").path("amount").asDouble();
//
//			acExist = amount > 0.0;
//
//			LOGGER.info("Amount from response: {}", amount);
//
//		} catch (Exception e) {
//			LOGGER.error("Failed to validate account response", e);
//			isSuccess = false;
//		}
//
//		kcontext.setVariable("isSuccess", isSuccess);
//		kcontext.setVariable("acExist", acExist);
//
//		LOGGER.info("Set isSuccess = {}", isSuccess);
//		LOGGER.info("Set acExist = {}", acExist);
//	}
//
//	/**
//	 * Create Account
//	 *
//	 * onEntry: Sets up REST call config and payload
//	 */
//
//	public void initiateCreateAccountRequest(ProcessContext kcontext) {
//		LOGGER.info("Entering into : initiateCreateAccountRequest() method");
//
//		try {
////			String prefix = "createAccount";
////			String url = PropertyFile.get(prefix, BPMConstants.URL_KEY);
////			String method = PropertyFile.get(prefix, BPMConstants.METHOD_KEY);
////			String contentType = PropertyFile.get(BPMConstants.CONTENT_TYPE_KEY);
////			String authType = PropertyFile.get(BPMConstants.AUTH_TYPE_KEY);
//			
//			
//			String url = (String) kcontext.getVariable(BPMConstants.CREATE_ACCOUNT_URL);
//			String method = (String) kcontext.getVariable(BPMConstants.CREATE_ACCOUNT_METHOD);
//			String contentType = (String) kcontext.getVariable(BPMConstants.CONTENT_TYPE_KEY);
//			String authType = (String) kcontext.getVariable(BPMConstants.AUTH_TYPE_KEY);
//
//			String aacSource = (String) kcontext.getVariable(BPMConstants.AAC_SOURCE_KEY);
//			String amount = (String) kcontext.getVariable(BPMConstants.CREATE_AC_AMOUNT);
//			if (aacSource == null || aacSource.trim().isEmpty()) {
//				throw new IllegalArgumentException("aac_source is missing in process context");
//			}
//
//			if (amount == null || amount.trim().isEmpty()) {
//				throw new IllegalArgumentException("amount is missing in process context");
//			}
//
//			kcontext.setVariable("amount", amount);
//
//			String requestPayload = String.format("{\"aac_source\": \"%s\"}", aacSource);
//
//			url = url + "?amount=" + amount;
//
//			kcontext.setVariable(BPMConstants.CREATE_ACCOUNT_URL, url);
//			kcontext.setVariable(BPMConstants.CREATE_ACCOUNT_METHOD, method);
//			kcontext.setVariable(BPMConstants.CONTENT_TYPE_KEY, contentType);
//			kcontext.setVariable(BPMConstants.AUTH_TYPE_KEY, authType);
//			kcontext.setVariable(BPMConstants.REQUEST_PAYLOAD, requestPayload);
//
//			LOGGER.info("REST URL for Create Account: {}", url);
//			LOGGER.info("Method: {}", method);
//			LOGGER.info("Content-Type: {}", contentType);
//			LOGGER.info("Auth Type: {}", authType);
//			LOGGER.info("Request Payload: {}", requestPayload);
//
//		} catch (Exception e) {
//			LOGGER.error("Error initiateCreateAccountRequest() method", e);
//			throw new RuntimeException("Failed to prepare initiateCreateAccountRequest REST call", e);
//		}
//	}
//
//	/**
//	 * onExit: Validates the response for Create Account
//	 */
//
//	public void validateCreateAccountResponse(ProcessContext kcontext) {
//		LOGGER.info("Entering into : validateCreateAccountResponse() method");
//
//		boolean isSuccess = true;
//
//		try {
//			String response = (String) kcontext.getVariable(BPMConstants.RESULT_VARIABLE);
//
//			if (response == null || !response.trim().equalsIgnoreCase("Account created successfully.")) {
//				throw new RuntimeException("Unexpected response: " + response);
//			}
//
//			LOGGER.info("Create Account response validated successfully.");
//
//		} catch (Exception e) {
//			LOGGER.error("Failed to validate Create Account response", e);
//			isSuccess = false;
//		}
//
//		kcontext.setVariable("isSuccess", isSuccess);
//
//		LOGGER.info("Setting success {}", isSuccess);
//
//	}
//
//}


package com.vzw.vxp.bpm.accountbalance.util;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.kie.api.runtime.process.ProcessContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.Serializable;

public class AccountDetailUtil implements Serializable {
    private static final long serialVersionUID = 1L;
    private static final Logger LOGGER = LoggerFactory.getLogger(AccountDetailUtil.class);

    public void initiateGetAccountProcessVariables(ProcessContext kcontext) {
        kcontext.setVariable(BPMConstants.CALL_COMPENSATION,
                null != kcontext.getVariable(BPMConstants.CALL_COMPENSATION)
                        ? (boolean) kcontext.getVariable(BPMConstants.CALL_COMPENSATION)
                        : false);
    }

    public void initiateGetAccountDetailsRequest(ProcessContext kcontext) {
        LOGGER.info("Entering into : initiateGetAccountDetailsRequest() method");

        try {
            String url = PropertyFile.getProperty("GET_ACCOUNT_URL");
            String method = PropertyFile.getProperty("GET_ACCOUNT_METHOD");
            String contentType = PropertyFile.getProperty("contentType");
            String authType = PropertyFile.getProperty("authType");

            String aacSource = (String) kcontext.getVariable(BPMConstants.AAC_SOURCE_KEY);
            if (aacSource == null || aacSource.trim().isEmpty()) {
                throw new IllegalArgumentException("aac_source is missing in process context");
            }

            String payload = String.format("{\"aac_source\": \"%s\"}", aacSource);

            kcontext.setVariable(BPMConstants.GET_ACCOUNT_URL, url);
            kcontext.setVariable(BPMConstants.GET_ACCOUNT_METHOD, method);
            kcontext.setVariable(BPMConstants.CONTENT_TYPE_KEY, contentType);
            kcontext.setVariable(BPMConstants.AUTH_TYPE_KEY, authType);
            kcontext.setVariable(BPMConstants.REQUEST_PAYLOAD, payload);

            LOGGER.info("REST URL for Get Account Details: {}", url);
            LOGGER.info("Method : {}", method);
            LOGGER.info("Content-Type: {}", contentType);
            LOGGER.info("Auth Type: {}", authType);
            LOGGER.info("Request Payload: {}", payload);

        } catch (Exception e) {
            LOGGER.error("Error in initiateGetAccountDetailsRequest()", e);
            throw new RuntimeException("Failed to prepare GetAccountDetails REST call", e);
        }
    }

    public void validateGetAccountDetailsResponse(ProcessContext kcontext) {
        LOGGER.info("Entering into : validateGetAccountDetailsResponse() method");

        boolean isSuccess = true;
        boolean acExist = false;

        try {
            String responseJson = (String) kcontext.getVariable(BPMConstants.RESULT_VARIABLE);
            ObjectMapper mapper = new ObjectMapper();
            JsonNode rootNode = mapper.readTree(responseJson);

            double amount = rootNode.path("data").path("amount").asDouble();
            acExist = amount > 0.0;

            LOGGER.info("Amount from response: {}", amount);

        } catch (Exception e) {
            LOGGER.error("Failed to validate account response", e);
            isSuccess = false;
        }

        kcontext.setVariable("isSuccess", isSuccess);
        kcontext.setVariable("acExist", acExist);
    }

    public void initiateCreateAccountRequest(ProcessContext kcontext) {
        LOGGER.info("Entering into : initiateCreateAccountRequest() method");

        try {
            String url = PropertyFile.getProperty("CREATE_ACCOUNT_URL");
            String method = PropertyFile.getProperty("CREATE_ACCOUNT_METHOD");
            String contentType = PropertyFile.getProperty("contentType");
            String authType = PropertyFile.getProperty("authType");
            String amount = PropertyFile.getProperty("CREATE_ACCOUNT_AMOUNT");

            String aacSource = (String) kcontext.getVariable(BPMConstants.AAC_SOURCE_KEY);
            if (aacSource == null || aacSource.trim().isEmpty()) {
                throw new IllegalArgumentException("aac_source is missing in process context");
            }

            if (amount == null || amount.trim().isEmpty()) {
                throw new IllegalArgumentException("Amount is missing in property file");
            }

            String requestPayload = String.format("{\"aac_source\": \"%s\"}", aacSource);
            url = url + "?amount=" + amount;

            kcontext.setVariable(BPMConstants.CREATE_ACCOUNT_URL, url);
            kcontext.setVariable(BPMConstants.CREATE_ACCOUNT_METHOD, method);
            kcontext.setVariable(BPMConstants.CONTENT_TYPE_KEY, contentType);
            kcontext.setVariable(BPMConstants.AUTH_TYPE_KEY, authType);
            kcontext.setVariable(BPMConstants.REQUEST_PAYLOAD, requestPayload);
            kcontext.setVariable("amount", amount);

            LOGGER.info("REST URL for Create Account: {}", url);
            LOGGER.info("Method: {}", method);
            LOGGER.info("Content-Type: {}", contentType);
            LOGGER.info("Auth Type: {}", authType);
            LOGGER.info("Request Payload: {}", requestPayload);

        } catch (Exception e) {
            LOGGER.error("Error in initiateCreateAccountRequest()", e);
            throw new RuntimeException("Failed to prepare CreateAccount REST call", e);
        }
    }

    public void validateCreateAccountResponse(ProcessContext kcontext) {
        LOGGER.info("Entering into : validateCreateAccountResponse() method");

        boolean isSuccess = true;

        try {
            String response = (String) kcontext.getVariable(BPMConstants.RESULT_VARIABLE);
            if (response == null || !response.trim().equalsIgnoreCase("Account created successfully.")) {
                throw new RuntimeException("Unexpected response: " + response);
            }
            LOGGER.info("Create Account response validated successfully.");
        } catch (Exception e) {
            LOGGER.error("Failed to validate Create Account response", e);
            isSuccess = false;
        }

        kcontext.setVariable("isSuccess", isSuccess);
    }
}
