package com.vzw.vxp.bpm.accountbalance.util;

public class BPMConstants {
	//Constants for the rest api calls 
	public static final String URL_KEY = "url";
	public static final String AUTH_TYPE_KEY = "authType";
	public static final String CONTENT_TYPE_KEY = "contentType";
	public static final String METHOD_KEY = "method";
	public static final String REQUEST_PAYLOAD = "requestPayload";
	public static final String RESULT_VARIABLE = "result";
	
	//Constants for the Account Details Process
	public static final String GET_ACCOUNT_URL = "GET_ACCOUNT_URL";
	public static final String GET_ACCOUNT_METHOD = "GET_ACCOUNT_METHOD";
	public static final String AAC_SOURCE_KEY = "aac_source";
	public static final String AC_EXIST_KEY = "acExist";
	public static final String CREATE_AC_AMOUNT = "CREATE_ACCOUNT_AMOUNT";
	public static final String CALL_COMPENSATION = "callCompensation";
	public static final String CREATE_ACCOUNT_URL = "CREATE_ACCOUNT_URL";
	public static final String CREATE_ACCOUNT_METHOD = "CREATE_ACCOUNT_METHOD";
	
	
}
