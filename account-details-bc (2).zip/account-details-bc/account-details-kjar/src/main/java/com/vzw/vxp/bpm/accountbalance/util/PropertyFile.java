//package com.vzw.vxp.bpm.accountbalance.util;
//
//import java.io.IOException;
//import java.io.InputStream;
//import java.util.Properties;
//
//public class PropertyFile {
//	private static final Properties properties = new Properties();
//
//	static {
//		try (InputStream input = PropertyFile.class.getClassLoader().getResourceAsStream("application.properties")) {
//			if (input != null) {
//				properties.load(input);
//			} else {
//				throw new RuntimeException("Unable to find application.properties");
//			}
//		} catch (IOException ex) {
//			throw new RuntimeException("Failed to load properties file", ex);
//		}
//	}
//
//	public static String get(String key) {
//		return properties.getProperty(key);
//	}
//
////	public static String get(String prefix, String key) {
////		return properties.getProperty(prefix + "." + key);
////	}
//}

package com.vzw.vxp.bpm.accountbalance.util;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

@Component
public class PropertyFile {
    private static Environment environment;

    @Autowired
    public PropertyFile(Environment env) {
        PropertyFile.environment = env;
    }

    public static String getProperty(String key) {
        return environment.getProperty(key);
    }
}
